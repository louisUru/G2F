<?php

namespace App\Controller;

use App\Entity\Employe;
use App\Entity\Formation;
use App\Entity\Inscription;
use App\Form\InscriptionType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\Persistence\ManagerRegistry;



class FormationController extends AbstractController
{
    #[Route('/formation', name: 'app_formation')]
    public function index(): Response
    {   
        echo "slt";
        return $this->render('formation/index.html.twig', [
            'controller_name' => 'FormationController',
        ]);
    }
    #[Route('/formation/inscriptiontest', name: 'app_formationInscript')]
    public function ajouttest(ManagerRegistry $doctrine){
        $entityManager = $doctrine->getManager();
        $insc1 = new Inscription();
        $insc1->setStatut("Validé");
        $employe=$doctrine->getManager()->getRepository(Employe::class)->find(1);
        $insc1->setLemploye($employe);
        $form1=$doctrine->getManager()->getRepository(Formation::class)->find(2);
        $insc1->setLaFormation($form1);
        echo "Inscription ajouté";
        $entityManager->persist($insc1);
        $entityManager->flush();
        return $this->render('formation/index.html.twig', [
            'controller_name' => 'FormationController',
        ]);
    }
    #[Route('/formation/affInscription/{idEmploye}', name: 'app_affInscriptionId')]
    public function afficheInscriptionAction($idEmploye,ManagerRegistry $doctrine){

        $insc=$doctrine->getManager()->getRepository(Inscription::class)->findByVoirInscEmploye($idEmploye);
        
        if (!$insc){
            $message = "Pas de formation";
        }
        else {
            $message = null;
        }
        return $this->render('formation/listeForm.html.twig', array('ensInscs'=>$insc, 'message'=>$message));
    }

    #[Route('/formation/InscEnAttente', name: 'app_InscFormationAttente')]
    public function formationAttenteAction(ManagerRegistry $doctrine){

        $form =$doctrine->getManager()->getRepository(Inscription::class)->findAll();
        if (!$form){
            $message = "Pas d'inscription en attente";
        }
        else {
            $message = null;
        }
        return $this->render('formation/listeinscriptions_enAttente.html.twig', array('lesInscriptions'=> $form, 'message'=>$message)
        );
    }


    #[Route('/formation/checkEdit/{id}', name: 'app_checkEmployeId')]
    public function checkEmployeIdAction($id,ManagerRegistry $doctrine, Request $request){
        $check =$doctrine->getRepository(Inscription::class)->find($id);
        $form = $this->createForm(InscriptionType::class, $check);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $em = $doctrine->getManager();
            $em->persist($check);
            $em->flush();
            return $this->redirectToRoute('app_InscFormationAttente');
        }
        return $this->render('formation/editerlisteinscriptions_enAttente.html.twig', 
                            array('form'=>$form->createView()));
    }



}
